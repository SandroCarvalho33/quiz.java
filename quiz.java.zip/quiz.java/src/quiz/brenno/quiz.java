package quiz.brenno;

import java.util.Scanner;

public class quiz {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int acertos = 0;

        cabecalho cabecalho = new cabecalho();

        cabecalho.aluno = "Aluno:Sandro Carvalho Jorge Almeida";
        cabecalho.professor = "Professor: Brenno Pimenta";
        cabecalho.curso = "Curso: Engenharia de software 2 ";
        cabecalho.materia = "Materia: Algortimo e Logica de Programaçao 2";
        cabecalho.escrevacabecalho();


        questoes questao1 = new questoes();


        questao1.questao1 = "Qual a moto mais rapida do mundo";
        questao1.A = "A)Yamaha: XJ6";
        questao1.B = "B)Honda: hornet";
        questao1.C = "C)Kawasaki: Ninja H2R";
        questao1.D = "D)Honda: CG160 com cabecote de twister";
        questao1.E = "E)Shineray: Eletrica com motor de liquidificador";
        questao1.escrevaquestao();
        questao1.correta = "C";
        System.out.println("Escreva questao correta:");
        String resposta = sc.nextLine();
        questao1.iscorreta(resposta);
        if (resposta.equals(questao1.correta)) {
            acertos = acertos + 1;
            System.out.println("numero de acertos:" + acertos);
        } else {
            System.out.println("Numero de acertos:" + acertos);
        }
    }
}