package quiz.brenno;

public class cabecalho {

    String escrevacabecalho = "";
    String aluno = "";

    String professor = "";

    String materia = "";


    String curso = "";


    public void escrevacabecalho(){
        System.out.println(this.escrevacabecalho);
        System.out.println(this.aluno);
        System.out.println(this.professor);
        System.out.println(this.materia);
        System.out.println(this.curso);
    }
}