package quiz.brenno;
public class questoes {

    String questao1 = "";

    String A = "";

    String B = "";

    String C = "";

    String D = "";

    String E = "";

    String correta = "";

    public void escrevaquestao(){
        System.out.println(this.questao1);
        System.out.println(this.A);
        System.out.println(this.B);
        System.out.println(this.C);
        System.out.println(this.D);
        System.out.println(this.E);
        System.out.println(this.correta);
    }
    public void iscorreta(String resposta){
        if(resposta.equals(this.correta)){
            System.out.println("RESPOSTA CORRETA, PARARABENS!!!");

            return;
        }
        else
            System.out.println("RESPOSTA ERRADA!!");
        System.out.println("A RESPOSTA CORRETA E " + this.correta);
    }
}
